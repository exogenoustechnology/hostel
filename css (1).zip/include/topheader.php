
<style>
    .social-icons a {
  display: inline-block;
  height: 34px;
  width: 24px;;
  border: none !important;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 17px !important;
   margin-top: -4px;
   width: 34px;
}

.text-black {
  color:#3d5479  !important;
  background-color: #fff;
}
.text-black a:hover, a.text-black:hover {
  color: #fe3f54 !important;
}

.listing span{
    color: #fff;
    font-size:16px;
    font-weight: bold !important;
    font-family: "roboto", sans-serif !important;  
}

@media only screen and (max-width: 600px) {
  .social-list {
    display: none;
  }
}

    </style>
<header class="navigation bg-tertiary">
	<nav class="navbar " style="background-color: #3d5479 !important; height: 41px;">


		<div class="container">
        <div class="listing">
            <span><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;&nbsp;support@hostelraja.com&nbsp;&nbsp;&nbsp;<i class="fa fa-phone" aria-hidden="true" style="transform: rotate(90deg);"></i>&nbsp;+91 96498 87888</span>
          </div>
          <div class="social-list">
          <ul class="list-unstyled list-inline mb-0 social-icons">
					 <li class="list-inline-item me-3"><a title="Explorer Facebook Profile" class="text-black" href="https://facebook.com/"><i class="fab fa-facebook-f"></i></a>
					</li>
					<li class="list-inline-item me-3"><a title="Explorer Twitter Profile" class="text-black" href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
					</li>
					<li class="list-inline-item me-3"><a title="Explorer Instagram Profile" class="text-black" href="https://instagram.com/"><i class="fab fa-instagram"></i></a>
					</li>
                    <li class="list-inline-item me-3"><a title="Explorer Whatsapp Profile" class="text-black" href="https://instagram.com/"><i class="fab fa-whatsapp"></i></a>
					</li> 
				</ul>
          </div>
		</div>
	</nav>
</header>