<!DOCTYPE html>
<html lang="en">
 <head>
<style>
.btn-outline-primary {
  background: #3d5479;
  color: #fff;
}

.btn-primary {
  background: #3d5479;
  color: #fff;
  border-color: #3d5479;
}
.btn-outline-primary:hover, .btn-outline-primary:active, .btn-outline-primary.active, .btn-outline-primary:focus, .btn-outline-primary.focus {
  background: #fff !important;
  color: #fff !important;
}
.btn:hover, .btn:active, .btn.active, .btn:focus, .btn.focus {
  outline: 0;
  box-shadow: none !important;
  text-decoration: none;
}
.btn-primary:hover, .btn-primary:active, .btn-primary.active, .btn-primary:focus, .btn-primary.focus {
  background: #fff !important;
  color: #fff;
}
.modal-header {
  display: flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: space-between;
  padding: 1rem 1rem;
  border-bottom: none;
  border-top-left-radius: calc(0.3rem - 1px);
  border-top-right-radius: calc(0.3rem - 1px);
}

.modal-footer {
  display: flex;
  flex-wrap: wrap;
  flex-shrink: 0;
  align-items: center;
  justify-content: flex-end;
  padding: 0.75rem;
  border-top: none;
  border-bottom-right-radius: calc(0.3rem - 1px);
  border-bottom-left-radius: calc(0.3rem - 1px);
}

.listpass {
text-align: center;
margin-top: 14px;
}
.modal-header {
  display: flex;
  justify-content: center;
  margin-top: 15px;
}
/* .modal-content{
background-image: url("images/pic.png");
background-repeat: none;
} */
    </style>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="//geodata.solutions/includes/statecity.js"></script>
	</head>
<body>
<header class="navigation bg-tertiary">
	<nav class="navbar navbar-expand-xl navbar-light text-center py-3">


		<div class="container">
			<a class="navbar-brand" href="index.php">
				<img loading="prelaod" decoding="async" class="img-fluid" width="100" src="images/hostelraja.png" alt="Wallet">
			</a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav mx-auto mb-2 mb-lg-0">
					<li class="nav-item"> <a class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item "> <a class="nav-link" href="about.php">About</a>
					</li>
					<li class="nav-item "> <a class="nav-link" href="find-my-pg.php">Find My PG</a>
					</li>
					<li class="nav-item "> <a class="nav-link" href="signup.php">For PG owners</a>
					</li>
					<li class="nav-item "> <a class="nav-link" href="blog.php">Blog</a>
					</li>
					<li class="nav-item "> <a class="nav-link" href="contact.php">Contact</a>
					</li>
				</ul>
				<!-- account btn --> <a href="login.php" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">Log In</a>
				<!-- account btn --> <a href="signup.php" class="btn btn-primary ms-2 ms-lg-3" data-bs-toggle="modal" data-bs-target="#exampleModal1">Sign Up</a>
			</div>
		</div>
	</nav>
</header>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><img loading="prelaod" decoding="async" class="img-fluid" width="80" src="images/hostelraja.png" alt="Wallet"></h5>
        <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body">
	  <form action="#!" method="post">
          <div class="row">
            <div class="col-lg-12 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_full_name" class="form-label">Email / Mobile No.*</label>
                <input type="text" class="form-control shadow-none" id="loan_full_name">
              </div>
            </div>
            <div class="col-lg-12 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_password" class="form-label">Password</label>
                <input type="password" class="form-control shadow-none" id="loan_password">
              </div>
            </div>
			<div class="col-lg-3">
           </div>
            <div class="col-lg-6">
              <button type="submit" class="btn btn-primary w-100">Log in</button>
            </div>
			<div class="col-lg-3">
           </div>
		   <div class="col-lg-6">
		   <div class="listpass"><a href="https://hostelraja.com/signup.php" style="color: #ff3b54 !important;"> New Registration</a></div>
           </div>
            <div class="col-lg-6">
			<div class="listpass"><a href="forgot-password.php" style="color: #ff3b54 !important;">Forgot Password?</a></div>
            </div>
          </div>
        </form>

      </div>
      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div> -->
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header" style=" ">
      <h5 class="modal-title" id="exampleModalLabel"><img loading="prelaod" decoding="async" class="img-fluid" width="80" src="images/hostelraja.png" alt="Wallet"></h5>
        <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body">
      <form action="#!" method="post">
          <div class="row">
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_full_name" class="form-label">Pg Name*</label>
                <input type="text" class="form-control shadow-none" id="loan_full_name">
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_password" class="form-label">contact 1*</label>
                <input type="password" class="form-control shadow-none" id="loan_password">
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_full_name" class="form-label">contact 2*</label>
                <input type="text" class="form-control shadow-none" id="loan_full_name">
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_password" class="form-label">Branch Type*</label>
                <select class="form-control" name="type" required="">
                  <option value="1">Boys</option>
                  <option value="2">Girls</option>
                  <option value="3">Co-Ed</option>
                </select>
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_full_name" class="form-label">Owner Name*</label>
                <input type="text" class="form-control shadow-none" id="loan_full_name">
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_owner" class="form-label">Owner Mail*</label>
                <input type="text" class="form-control shadow-none" id="loan_password">
              </div>
            </div>
            <div class="col-lg-12 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_address" class="form-label">Address*</label>
                <input type="text" class="form-control shadow-none" id="loan_address">
              </div>
            </div>
            <div class="col-lg-12 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_full_name" class="form-label">PAN Number*</label>
                <input type="text" class="form-control shadow-none" id="loan_full_name">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_password" class="form-label">State*</label>
                <select name="state" class="states order-alpha form-control " id="stateId">
                  <option value="">Select State</option>
              </select>
                            </div>
            </div>
         
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_password" class="form-label">City*</label>
                <input type="hidden" name="country" id="countryId" value="IN"/>
                <select name="city" class="cities order-alpha form-control" id="cityId">
                    <option value="">Select City</option>
                </select>
              </div>
            </div></div>
          <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Save</button>
        <button type="button" class="btn btn-primary">cancel</button>
      </div>
          
        </form>

      
      </div>
    
    </div>
  </div>
</div>
</body>
</html>