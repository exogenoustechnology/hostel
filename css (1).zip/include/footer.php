<style>
	.text-primary {
  color: #18325d !important;
}
.bg-primary {
  background: #18325d !important;
}

.newsletter-form input, .newsletter-form .input-group-text {
  border-color: #18325d !important;
}
	</style>
<footer class="section-sm bg-tertiary">
	<div class="container">
		<div class="row justify-content-between">
			<div class="col-lg-3 col-md-4 col-6 mb-4">
				<div class="footer-widget">
					<h5 class="mb-4 text-primary font-secondary">About Us</h5>
					<ul class="list-unstyled">
						<li class="mb-2">
			<p class="mb-0">Made Life easier with Hostelraja. Get everything done, right from payments to all updates with us. Stay connected with the best Hostel/PG finding & managing services.</p>
						</li>
					</ul>
					<ul class="list-unstyled list-inline mb-0 social-icons">
					<li class="list-inline-item me-3"><a title="Explorer Facebook Profile" class="text-black" href="https://facebook.com/"><i class="fab fa-facebook-f"></i></a>
					</li>
					<li class="list-inline-item me-3"><a title="Explorer Twitter Profile" class="text-black" href="https://twitter.com/"><i class="fab fa-twitter"></i></a>
					</li>
					<li class="list-inline-item me-3"><a title="Explorer Instagram Profile" class="text-black" href="https://instagram.com/"><i class="fab fa-instagram"></i></a>
					</li>
				</ul>
				</div>
			</div>
			<div class="col-lg-2 col-md-4 col-6 mb-4">
				<div class="footer-widget">
					<h5 class="mb-4 text-primary font-secondary">Quick Link</h5>
					<ul class="list-unstyled">
						<li class="mb-2"><a href="https://hostelraja.com/">Home</a>
						</li>
						<li class="mb-2"><a href="https://hostelraja.com/about.php">About Us</a>
						</li>
						<li class="mb-2"><a href="https://hostelraja.com/find-my-pg.php">Find My PG</a>
						</li>
						<li class="mb-2"><a href="https://hostelraja.com/blog.php">Blogs</a>
						</li>
						<li class="mb-2"><a href="https://hostelraja.com/contact.php">Contact Us</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-lg-2 col-md-4 col-6 mb-4">
				<div class="footer-widget">
					<h5 class="mb-4 text-primary font-secondary">Contact Details</h5>
					<ul class="list-unstyled">
						<li class="mb-2"><a href="">314, 3rd Floor, Balaji tower, Durgapur Flyover, Tonk Road Jaipur, Rajasthan, 302018</a>
						</li>
						<li class="mb-2"><a href="tel:+919649887888">+91 96498 87888</a>
						</li>
						<li class="mb-2"><a href="">support@hostelraja.com</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-lg-4 col-md-12 newsletter-form">
				<div style="background-color: #F4F4F4; padding: 35px;">
					<h5 class="mb-4 text-primary font-secondary">Get In Touch</h5>
					<div class="pe-0 pe-xl-5">
						<form action="#!" method="post" name="mc-embedded-subscribe-form" target="_blank">
							<div class="input-group mb-3">
								<input type="text" class="form-control shadow-none bg-white border-end-0" placeholder="Email address"> <span class="input-group-text border-0 p-0">
                    <button class="input-group-text border-0 bg-primary" type="submit" name="subscribe"
                      aria-label="Subscribe for Newsletter"><i class="fas fa-arrow-right"></i></button>
                  </span>
							</div>
							<div style="position: absolute; left: -5000px;" aria-hidden="true">
								<input type="text" name="b_463ee871f45d2d93748e77cad_a0a2c6d074" tabindex="-1">
							</div>
						</form>
					</div>
					<p class="mb-0">You can reach us today by calling or emailing us and a member of the Hostelraja team will respond to your inquiry as soon as possible.</p>
				</div>
			</div>
		</div>
		<div class="row align-items-center mt-5 text-center text-md-start">
			<div class="col-lg-4">
        <a href="index.php">
          <img loading="prelaod" decoding="async" class="img-fluid" width="100" src="images/hostelraja.png" alt="Wallet">
        </a>
			</div>
			<div class="col-lg-6 col-md-6 mt-4 mt-lg-0">
				<ul class="list-unstyled list-inline mb-0 text-lg-center" style="background-color: #fbfbfb" >
					<li class="list-inline-item me-4"><a class="text-black" href="privacy-policy.php">Privacy Policy</a>
					</li>
					<li class="list-inline-item me-4"><a class="text-black" href="terms-conditions.php">Terms &amp; Conditions</a>
					</li>
					<li class="list-inline-item me-4"><a class="text-black" href="refund-policy.php">Refund Policy </a>
					</li>
				</ul>
			</div>
			
		</div>
	</div>
</footer>
<div class="container-fluid" style="background-color: #18325d;text-align: center;margin-top: -46px;">
		<div class="row">
			<div class="col-lg-12">
			<p style="font-size:17 ;margin-top: 10px; color:#fff;"> © <span class="current-year">2022</span> HostelRaja All Rights Resurved</p>
         </div>
		</div>
	</div>