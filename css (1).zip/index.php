<?php include ("include/headerlink.php"); ?>
<?php include ("include/topheader.php"); ?>
<?php include ("include/menu.php"); ?>
<!DOCTYPE html>
<html lang="en">
 <head>
<!-- Link Swiper's CSS -->
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css"/>

<style>
 .swiper {
        width: 100%;
        height: 100%;
      }

      .swiper-slide {
        text-align: center;
        font-size: 18px;
        background: #fff;

        /* Center slide text vertically */
        display: -webkit-box;
        display: -ms-flexbox;
        display: -webkit-flex;
        display: flex;
        -webkit-box-pack: center;
        -ms-flex-pack: center;
        -webkit-justify-content: center;
        justify-content: center;
        -webkit-box-align: center;
        -ms-flex-align: center;
        -webkit-align-items: center;
        align-items: center;
      }

      .swiper-slide img {
        display: block;
        width: 100%;
        height: 100%;
        object-fit: cover;
      }
      .banner {
  padding: 90px 0;
  z-index: 0 !important;
}
.ameimg{
  width: 95px;
}

.category-amenities{
  box-shadow: 0 .5rem 1rem rgba(0,0,0,.15) !important;
  border: none;
margin-bottom: 50px;
width: 200px;
height: 284px;
margin-left: 15px;
margin-right: 15px;
}
.amenities-icon{
 display: flex;
justify-content: center;
align-items: center;
  width: auto;
  height: 250px;
  text-align: center;
}
.category-title{
font-size: 18px;
font-weight: 600;
color:#3d5479;
}

.section {
  padding-top: 60px !important;
  padding-bottom: 40px !important;
}
  </style>
</head>
<body>
<div class="modal applyLoanModal fade" id="applyLoan" tabindex="-1" aria-labelledby="applyLoanLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header border-bottom-0">
        <h4 class="modal-title" id="exampleModalLabel">How much do you need?</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="#!" method="post">
          <div class="row">
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_amount" class="form-label">Amount</label>
                <input type="number" class="form-control shadow-none" id="loan_amount" placeholder="ex: 25000">
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_how_long_for" class="form-label">How long for?</label>
                <input type="number" class="form-control shadow-none" id="loan_how_long_for" placeholder="ex: 12">
              </div>
            </div>
            <div class="col-lg-12 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_repayment" class="form-label">Repayment</label>
                <input type="number" class="form-control shadow-none" id="loan_repayment" disabled>
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_full_name" class="form-label">Full Name</label>
                <input type="text" class="form-control shadow-none" id="loan_full_name">
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_email_address" class="form-label">Email address</label>
                <input type="email" class="form-control shadow-none" id="loan_email_address">
              </div>
            </div>
            <div class="col-lg-12">
              <button type="submit" class="btn btn-primary w-100">Get Your Loan Now</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<section class="">
  <div class="container-fulid">
    <div class="row">
      <div class="swiper mySwiper">
        <div class="swiper-wrapper">
          <div class="swiper-slide"><img src="images/hostel1raja.png"></div>
          <div class="swiper-slide"><img src="images/hostel1raja.png"></div>
        </div>
      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>
    </div>
</div>
</section>

<section class="about-section section bg-tertiary position-relative overflow-hidden">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-5">
        <div class="section-title">
          <p class="text-primary text-uppercase fw-bold mb-3">About Us</p>
          <h1>Getting & managing a good PG/Hostel is tough, but here we bring you the Best!</h1>
          <p class="lead mb-0 mt-4">
            <p>Finding and Managing PG/Hostel was never so easy. Hostelraja is the one-stop solution for finding and managing PG/Hostel/Accommodations. Our goal is to make you getting PG/Hostels a hassle-free experience. Also, we provide applications for Hostels/PGs to manage all the services digitally without any complications and long documentation. </p>
            <p>We know why exactly you need accommodation in a new city, whether you are looking for PG, Hostels, or rooms we got you all covered. Our motive is to give a smooth and top-notch experience in every city you are searching for all over India. Hostelraja keeps records updated of the tenants, about their meals, lodging, complaints, fees, transfer room, and other facilities. We also gather feedback for the regular improvement of us and the individuals using our applications.</p>
          </p> <a class="btn btn-primary mt-4" href="about.php">Know About Us</a>
        </div>
      </div>
      <div class="col-lg-7 text-center text-lg-end">
        <img loading="lazy" decoding="async" src="images/about-us.png" alt="About Ourselves" class="img-fluid">
      </div>
    </div>
  </div>
  <div class="has-shapes">
    <svg class="shape shape-left text-light" width="381" height="443" viewBox="0 0 381 443" fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M334.266 499.007C330.108 469.108 304.151 446.496 276.261 435.921C248.372 425.346 218.077 424.035 188.666 419.32C159.254 414.589 128.795 405.375 108.664 383.129C72.8533 343.535 83.3445 282.01 77.7634 228.587C69.3017 147.754 15.4873 73.3967 -58.0001 40.9907"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M349.584 485.51C345.427 455.611 319.469 433 291.58 422.425C263.69 411.85 233.395 410.538 203.984 405.823C174.573 401.092 144.114 391.878 123.982 369.632C88.1716 330.038 98.6628 268.513 93.0817 215.09C84.62 134.258 30.8056 59.8999 -42.6819 27.494"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M364.904 472.013C360.747 442.114 334.789 419.503 306.9 408.928C279.011 398.352 248.716 397.041 219.304 392.326C189.893 387.595 159.434 378.381 139.303 356.135C103.492 316.541 113.983 255.016 108.402 201.593C99.9403 120.76 46.1259 46.4028 -27.3616 13.9969"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M380.24 458.516C376.083 428.617 350.125 406.006 322.236 395.431C294.347 384.856 264.051 383.544 234.64 378.829C205.229 374.098 174.77 364.884 154.639 342.638C118.828 303.044 129.319 241.519 123.738 188.096C115.276 107.264 61.4619 32.906 -12.0255 0.500103"
        stroke="currentColor" stroke-miterlimit="10" />
    </svg>
    <svg class="shape shape-right text-light" width="406" height="433" viewBox="0 0 406 433" fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M101.974 -86.77C128.962 -74.8992 143.467 -43.2447 146.175 -12.7857C148.883 17.6734 142.273 48.1263 139.087 78.5816C135.916 109.041 136.681 141.702 152.351 167.47C180.247 213.314 240.712 218.81 289.413 238.184C363.095 267.516 418.962 340.253 430.36 421.687"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M118.607 -98.5031C145.596 -86.6323 160.101 -54.9778 162.809 -24.5188C165.517 5.94031 158.907 36.3933 155.72 66.8486C152.549 97.3082 153.314 129.969 168.985 155.737C196.881 201.581 257.346 207.077 306.047 226.451C379.729 255.783 435.596 328.52 446.994 409.954"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M135.241 -110.238C162.23 -98.3675 176.735 -66.7131 179.443 -36.254C182.151 -5.79492 175.541 24.6581 172.354 55.1134C169.183 85.573 169.948 118.234 185.619 144.002C213.515 189.846 273.98 195.342 322.681 214.716C396.363 244.048 452.23 316.785 463.627 398.219"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M151.879 -121.989C178.867 -110.118 193.373 -78.4638 196.081 -48.0047C198.789 -17.5457 192.179 12.9074 188.992 43.3627C185.821 73.8223 186.586 106.483 202.256 132.251C230.153 178.095 290.618 183.591 339.318 202.965C413.001 232.297 468.867 305.034 480.265 386.468"
        stroke="currentColor" stroke-miterlimit="10" />
    </svg>
  </div>
</section>



<section class="section">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-6">
        <div class="section-title pt-4">
          <p class="text-primary text-uppercase fw-bold mb-3">What We Offer</p>
          <h1>Elementary Purpose of HostelRaja</h1>
          <p>Managing a hostel/PG is certainly a challenge, so making these complications unproblematic Hostel raja provides an online management system with unique and significant steps.  Hostelraja is high on technology and helps you manage your stay, food, rent, internet, maid, and cleaning requests all in just a <a href="https://hostelraja.com/signup.php">click away</a></p>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 service-item">
        <a class="text-black" href="service-details.html">
          <div class="block"> <span class="colored-box text-center h3 mb-4">01</span>
            <h3 class="mb-3 service-title">Cloud-Based Software</h3>
            <p class="mb-0 service-description">We offer cloud-based software so that you can have Infinite storage, backup, easy accessibility, and data recovery available anytime anywhere in your pocket.</p>
          </div>
        </a>
      </div>
      <div class="col-lg-4 col-md-6 service-item">
        <a class="text-black" href="service-details.html">
          <div class="block"> <span class="colored-box text-center h3 mb-4">02</span>
            <h3 class="mb-3 service-title">Complete Monitoring</h3>
            <p class="mb-0 service-description">Track every detail like tenant rent, room details, water & electricity bills also remainder notifications on our dashboard with efficiency for organized workflow.</p>
          </div>
        </a>
      </div>
      <div class="col-lg-4 col-md-6 service-item">
        <a class="text-black" href="service-details.html">
          <div class="block"> <span class="colored-box text-center h3 mb-4">
              03
            </span>
            <h3 class="mb-3 service-title">User-Friendly Interface</h3>
            <p class="mb-0 service-description">Simple design for easy understanding for every visitor. Also, our services are co-designed so that they can operate seamlessly and incorporate actively.</p>
          </div>
        </a>
      </div>
      <div class="col-lg-4 col-md-6 service-item">
        <a class="text-black" href="service-details.html">
          <div class="block"> <span class="colored-box text-center h3 mb-4">


              04

            </span>
            <h3 class="mb-3 service-title">Detailed Reports</h3>
            <p class="mb-0 service-description">Get all information including tenant fees, meals, complaints, room transfer, complaints, and all details online on your fingertips hassle-free.</p>
          </div>
        </a>
      </div>
      <div class="col-lg-4 col-md-6 service-item">
        <a class="text-black" href="service-details.html">
          <div class="block"> <span class="colored-box text-center h3 mb-4">


              05

            </span>
            <h3 class="mb-3 service-title">Fast & Secured Process</h3>
            <p class="mb-0 service-description">Receive a quick automated process for tenant dues, check-ins, check-outs, room details, and much more with our secured encrypted services.</p>
          </div>
        </a>
      </div>
    </div>
  </div>
</section>


<section class="section">
  <div class="container">
    <div class="row align-items-center justify-content-between">
      <div class="col-lg-5">
        <div class="section-title">
          <p class="text-primary text-uppercase fw-bold mb-3">How It Works</p>
          <h1>What Makes Us <br> Different Form Other?</h1>
          <div class="content mb-0 mt-4">
            <p>Hostelraja is an end-to-end platform where you can search for the best-suited hostel/PGs and this unique platform also provides applications with which you can manage every detail efficiently in one place.</p>
          </div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="difference-of-us-item p-3 rounded mr-0 me-lg-4">
          <div class="d-block d-sm-flex align-items-center m-2">
            <div class="icon me-4 mb-4 mb-sm-0"> <i class="fas fa-shield-alt mt-4" style="font-size:36px"></i>
            </div>
            <div class="block">
              <h3 class="mb-3">Flexible Plans</h3>
              <p class="mb-0">Adjust, monitor risks and challenges, and improve working accordingly.</p>
            </div>
          </div>
        </div>
        <div class="difference-of-us-item p-3 rounded mr-0 me-lg-4">
          <div class="d-block d-sm-flex align-items-center m-2">
            <div class="icon me-4 mb-4 mb-sm-0"> <i class="fas fa-blender-phone mt-4" style="font-size:36px"></i>
            </div>
            <div class="block">
              <h3 class="mb-3">Quick Question Answers</h3>
              <p class="mb-0">Constant feedback more engagement with customers.</p>
            </div>
          </div>
        </div>
        <div class="difference-of-us-item p-3 rounded mr-0 me-lg-4">
          <div class="d-block d-sm-flex align-items-center m-2">
            <div class="icon me-4 mb-4 mb-sm-0"> <i class="fas fa-money-bill-alt mt-4" style="font-size:36px"></i>
            </div>
            <div class="block">
              <h3 class="mb-3">We Get You Your Cash Quick</h3>
              <p class="mb-0">Go digital with us and opt for fast online payment modes.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="amenities">
  <div class="section container" style="padding-top: 10px;">
    <div class="row justify-content-center">
    <h1 style="text-align:center; color: #3d5479; font-size: 40px;font-weight: 600;margin-bottom: 42;">Building / Room Amenities </h1>
                    <div class="col-lg-3 col-sm-6 col-12 category-amenities">
                    <div class="amenities-icon">
                    <a href=""><span ><img class="ameimg" src="images/fast-food.png" alt="#"></span><br><br>
                    <span class="category-title">Food</span></a>
                    </div>
</div>
                    <div class="col-lg-3 col-sm-6 col-12 category-amenities">
                    <div class="amenities-icon">
                    <a href=""><span><img class="ameimg" src="images/air-conditioner.png" alt="#"></span><br><br>
                    <span class="category-title">Air conditioner</span></a>
                    </div>
</div>
                    <div class="col-lg-3 col-sm-6 col-12 category-amenities">
                    <div class="amenities-icon">
                    <a href=""><span><img class="ameimg" src="images/balcony.png" alt="#"></span><br><br>
                    <span class="category-title">Balcony</span></a>
</div>
</div>
                    <div class="col-lg-3 col-sm-6 col-12 category-amenities">
                    <div class="amenities-icon">
                    <a href=""><span><img class="ameimg" src="images/kitchen.png" alt="#"></span><br><br>
                    <span class="category-title">Kitchen Amenities</span></a>
</div>
                    </div>
                    <div class="row justify-content-center">
                    <div class="col-lg-3 col-sm-6 col-12 category-amenities">
                    <div class="amenities-icon">
                    <a href=""><span><img class="ameimg" src="images/wifi.png" alt="#"></span><br><br>
                    <span class="category-title">Wi-Fi</span></a>
                    </div>
</div>
                    <div class="col-lg-3 col-sm-6 col-12 category-amenities">
                    <div class="amenities-icon">
                    <a href=""><span><img class="ameimg" src="images/washing-machine.png" alt="#"></span><br><br>
                    <span class="category-title">Cleaning & Washing</span></a>
</div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-12 category-amenities">
                    <div class="amenities-icon">
                    <a href=""><span class=""><img class="ameimg" src="images/television.png" alt="#"></span><br><br>
                    <span class="category-title">Tv</span></a>
                    </div>
                    </div>
                    <div class="col-lg-3 col-sm-6 col-12 category-amenities">
                      <div class="amenities-icon">
                    <a href=""><span><img class="ameimg" src="images/water-heater.png" alt="#"></span><br><br>
                    <span class="category-title">Water Heater</span></a>
                    </div>
                  </div>
                </div>
  </div>
</section>

<section class="section testimonials overflow-hidden bg-tertiary">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-6">
        <div class="section-title text-center">
          <p class="text-primary text-uppercase fw-bold mb-3">What Our Clients Say About Us</p>
          <h1 class="mb-4">Trusted By 1.2K+ Peoples</h1>
          <p class="lead mb-0">We are very fortunate to have formed excellent partnerships with many of our clients. And we’ve formed more than just working relationships with them; we have formed true friendships. Here’s what they’re saying about us.</p>
        </div>
      </div>
    </div>
    <div class="row position-relative">
      <div class="col-lg-4 col-md-6 pt-1">
        <div class="shadow rounded bg-white p-4 mt-4">
          <div class="d-block d-sm-flex align-items-center mb-3">
            <img loading="lazy" decoding="async"
              src="images/testimonials/01.jpg"
              alt="Leslie Alexander" class="img-fluid" width="65" height="66">
            <div class="mt-3 mt-sm-0 ms-0 ms-sm-3">
              <h4 class="h5 mb-1">Leslie Alexander</h4>
              <p class="mb-0">PG ownner</p>
            </div>
          </div>
          <div class="content">Lorem ipsum dolor <a href="http://google.com">@reamansimond</a> demina egestas sit purus
            felis arcu. Vitae, turpisds tortr etiam faucibus ac suspendisse.</div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 pt-1">
        <div class="shadow rounded bg-white p-4 mt-4">
          <div class="d-block d-sm-flex align-items-center mb-3">
            <img loading="lazy" decoding="async"
              src="images/testimonials/02.jpg"
              alt="Arlene McCoy" class="img-fluid" width="65" height="66">
            <div class="mt-3 mt-sm-0 ms-0 ms-sm-3">
              <h4 class="h5 mb-1">Arlene McCoy</h4>
              <p class="mb-0">Hostel Owner</p>
            </div>
          </div>
          <div class="content">Lorem ipsum dolor <a href="http://google.com">@reamansimond</a> demina egestas sit purus
            felis arcu. Vitae, turpisds tortr etiam faucibus ac suspendisse.</div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 pt-1">
        <div class="shadow rounded bg-white p-4 mt-4">
          <div class="d-block d-sm-flex align-items-center mb-3">
            <img loading="lazy" decoding="async"
              src="images/testimonials/03.jpg"
              alt="Marvin McKinney" class="img-fluid" width="65" height="66">
            <div class="mt-3 mt-sm-0 ms-0 ms-sm-3">
              <h4 class="h5 mb-1">Marvin McKinney</h4>
              <p class="mb-0">Hostel Owner</p>
            </div>
          </div>
          <div class="content">Lorem ipsum dolor <a href="http://google.com">@reamansimond</a> demina egestas sit purus
            felis arcu. Vitae, turpisds tortr etiam faucibus ac suspendisse.</div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 pt-1">
        <div class="shadow rounded bg-white p-4 mt-4">
          <div class="d-block d-sm-flex align-items-center mb-3">
            <img loading="lazy" decoding="async"
              src="images/testimonials/04.jpg"
              alt="Devon Lane" class="img-fluid" width="65" height="66">
            <div class="mt-3 mt-sm-0 ms-0 ms-sm-3">
              <h4 class="h5 mb-1">Devon Lane</h4>
              <p class="mb-0">Hostel Owner</p>
            </div>
          </div>
          <div class="content">Lorem ipsum dolor <a href="http://google.com">@reamansimond</a> demina egestas sit purus
            felis arcu. Vitae, turpisds tortr etiam faucibus ac suspendisse.</div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 pt-1">
        <div class="shadow rounded bg-white p-4 mt-4">
          <div class="d-block d-sm-flex align-items-center mb-3">
            <img loading="lazy" decoding="async"
              src="images/testimonials/05.jpg"
              alt="Bessie Cooper" class="img-fluid" width="65" height="66">
            <div class="mt-3 mt-sm-0 ms-0 ms-sm-3">
              <h4 class="h5 mb-1">Bessie Cooper</h4>
              <p class="mb-0">Hostel Owner</p>
            </div>
          </div>
          <div class="content">Lorem ipsum dolor <a href="http://google.com">@reamansimond</a> demina egestas sit purus
            felis arcu. Vitae, turpisds tortr etiam faucibus ac suspendisse.</div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 pt-1">
        <div class="shadow rounded bg-white p-4 mt-4">
          <div class="d-block d-sm-flex align-items-center mb-3">
            <img loading="lazy" decoding="async"
              src="images/testimonials/06.jpg"
              alt="Kathryn Murphy" class="img-fluid" width="65" height="66">
            <div class="mt-3 mt-sm-0 ms-0 ms-sm-3">
              <h4 class="h5 mb-1">Kathryn Murphy</h4>
              <p class="mb-0">Hostel Owner</p>
            </div>
          </div>
          <div class="content">Lorem ipsum dolor <a href="http://google.com">@reamansimond</a> demina egestas sit purus
            felis arcu. Vitae, turpisds tortr etiam faucibus ac suspendisse.</div>
        </div>
      </div>
    </div>
  </div>
  <div class="has-shapes">
    <svg class="shape shape-left text-light" width="290" height="709" viewBox="0 0 290 709" fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M-119.511 58.4275C-120.188 96.3185 -92.0001 129.539 -59.0325 148.232C-26.0649 166.926 11.7821 174.604 47.8274 186.346C83.8726 198.088 120.364 215.601 141.281 247.209C178.484 303.449 153.165 377.627 149.657 444.969C144.34 546.859 197.336 649.801 283.36 704.673"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M-141.434 72.0899C-142.111 109.981 -113.923 143.201 -80.9554 161.895C-47.9878 180.588 -10.1407 188.267 25.9045 200.009C61.9497 211.751 98.4408 229.263 119.358 260.872C156.561 317.111 131.242 391.29 127.734 458.631C122.417 560.522 175.414 663.463 261.437 718.335"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M-163.379 85.7578C-164.056 123.649 -135.868 156.869 -102.901 175.563C-69.9331 194.256 -32.086 201.934 3.9592 213.677C40.0044 225.419 76.4955 242.931 97.4127 274.54C134.616 330.779 109.296 404.957 105.789 472.299C100.472 574.19 153.468 677.131 239.492 732.003"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M-185.305 99.4208C-185.982 137.312 -157.794 170.532 -124.826 189.226C-91.8589 207.919 -54.0118 215.597 -17.9666 227.34C18.0787 239.082 54.5697 256.594 75.4869 288.203C112.69 344.442 87.3706 418.62 83.8633 485.962C78.5463 587.852 131.542 690.794 217.566 745.666"
        stroke="currentColor" stroke-miterlimit="10" />
    </svg>
    <svg class="shape shape-right text-light" width="731" height="429" viewBox="0 0 731 429" fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <path
        d="M12.1794 428.14C1.80036 390.275 -5.75764 349.015 8.73984 312.537C27.748 264.745 80.4729 237.968 131.538 231.843C182.604 225.703 234.032 235.841 285.323 239.748C336.615 243.64 391.543 240.276 433.828 210.964C492.452 170.323 511.701 91.1227 564.607 43.2553C608.718 3.35334 675.307 -9.81661 731.29 10.323"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M51.0253 428.14C41.2045 392.326 34.0538 353.284 47.7668 318.783C65.7491 273.571 115.623 248.242 163.928 242.449C212.248 236.641 260.884 246.235 309.4 249.931C357.916 253.627 409.887 250.429 449.879 222.701C505.35 184.248 523.543 109.331 573.598 64.0588C615.326 26.3141 678.324 13.8532 731.275 32.9066"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M89.8715 428.14C80.6239 394.363 73.8654 357.568 86.8091 325.028C103.766 282.396 150.788 258.515 196.347 253.054C241.906 247.578 287.767 256.629 333.523 260.099C379.278 263.584 428.277 260.567 465.976 234.423C518.279 198.172 535.431 127.525 582.62 84.8317C621.964 49.2292 681.356 37.4924 731.291 55.4596"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M128.718 428.14C120.029 396.414 113.678 361.838 125.837 331.274C141.768 291.221 185.939 268.788 228.737 263.659C271.536 258.515 314.621 267.008 357.6 270.282C400.58 273.556 446.607 270.719 482.028 246.16C531.163 212.111 547.275 145.733 591.612 105.635C628.572 72.19 684.375 61.1622 731.276 78.0432"
        stroke="currentColor" stroke-miterlimit="10" />
      <path
        d="M167.564 428.14C159.432 398.451 153.504 366.107 164.863 337.519C179.753 300.046 221.088 279.062 261.126 274.265C301.164 269.452 341.473 277.402 381.677 280.465C421.88 283.527 464.95 280.872 498.094 257.896C544.061 226.035 559.146 163.942 600.617 126.423C635.194 95.1355 687.406 84.8167 731.276 100.612"
        stroke="currentColor" stroke-miterlimit="10" />
    </svg>
  </div>
</section>


<section class="section testimonials overflow-hidden bg-tertiary">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-6">
        <div class="section-title text-center">
          <p class="text-primary text-uppercase fw-bold mb-3">Blogs</p>
          <h1 class="mb-4">Latest Blogs</h1>
        </div>
      </div>
    </div>
    <div class="row position-relative">
      <div class="col-lg-4 col-md-6 pt-1">
        <div class="shadow rounded bg-white">
          <div class="d-block  align-items-center ">
            <img loading="lazy" decoding="async"
              src="images/blog/post-1.jpg"
              alt="Why Do We Need The PG Management Solution?" class="img-fluid" width="100%" height="100">
            <div class="mt-3 mt-sm-0 ms-0 ms-sm-3">
              <h4 class="h5 mb-1" style="margin-top: 25px;"><a href="blog-details.php">Why Do We Need The PG Management Solution?</a>
</h4>
            </div>
          </div>
          <div class="content" style="padding: 0 9px 18px 17px;">Hostel/PGs Solution integrates with unlimited cloud storage. Cloud storage is brisk and secure. No more managing a pile of work is exhausting. All the details of staff and customers are stored within the app. </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 pt-1">
        <div class="shadow rounded bg-white">
          <div class="d-block  align-items-center ">
            <img loading="lazy" decoding="async"
              src="images/blog/post-1.jpg"
              alt="Why Do We Need The PG Management Solution?" class="img-fluid" width="100%" height="100">
            <div class="mt-3 mt-sm-0 ms-0 ms-sm-3">
              <h4 class="h5 mb-1" style="margin-top: 25px;"><a href="blog-details.php">Why Do We Need The PG Management Solution?</a>
</h4>
            </div>
          </div>
          <div class="content" style="padding: 0 9px 18px 17px;">Hostel/PGs Solution integrates with unlimited cloud storage. Cloud storage is brisk and secure. No more managing a pile of work is exhausting. All the details of staff and customers are stored within the app. </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 pt-1">
        <div class="shadow rounded bg-white">
          <div class="d-block  align-items-center ">
            <img loading="lazy" decoding="async"
              src="images/blog/post-1.jpg"
              alt="Why Do We Need The PG Management Solution?" class="img-fluid" width="100%" height="100">
            <div class="mt-3 mt-sm-0 ms-0 ms-sm-3">
              <h4 class="h5 mb-1" style="margin-top: 25px;"><a href="blog-details.php">Why Do We Need The PG Management Solution?</a>
</h4>
            </div>
          </div>
          <div class="content" style="padding: 0 9px 18px 17px;">Hostel/PGs Solution integrates with unlimited cloud storage. Cloud storage is brisk and secure. No more managing a pile of work is exhausting. All the details of staff and customers are stored within the app. </div>
          </div>
      </div>
        </div>
        </div>
      </div>
    </div>
  </div>
 
</section>

<section class="section">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-12">
        <div class="section-title text-center mb-5 pb-2">
          <p class="text-primary text-uppercase fw-bold mb-3">Questions You Have</p>
          <h1>Frequently Asked Questions</h1>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="accordion shadow rounded py-5 px-0 px-lg-4 bg-white position-relative" id="accordionFAQ">
          <div class="accordion-item p-1 mb-2">
            <h2 class="accordion-header accordion-button h5 border-0 active"
              id="heading-ebd23e34fd2ed58299b32c03c521feb0b02f19d9" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapse-ebd23e34fd2ed58299b32c03c521feb0b02f19d9" aria-expanded="true"
              aria-controls="collapse-ebd23e34fd2ed58299b32c03c521feb0b02f19d9">Which cities does Hostelraja operate in?
            </h2>
            <div id="collapse-ebd23e34fd2ed58299b32c03c521feb0b02f19d9"
              class="accordion-collapse collapse border-0 show"
              aria-labelledby="heading-ebd23e34fd2ed58299b32c03c521feb0b02f19d9" data-bs-parent="#accordionFAQ">
              <div class="accordion-body py-0 content">Hostelraja provides rental accommodations to students and working professionals all over India with 100% verified PGs/Hostels.</div>
            </div>
          </div>
          <div class="accordion-item p-1 mb-2">
            <h2 class="accordion-header accordion-button h5 border-0 "
              id="heading-a443e01b4db47b3f4a1267e10594576d52730ec1" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapse-a443e01b4db47b3f4a1267e10594576d52730ec1" aria-expanded="false"
              aria-controls="collapse-a443e01b4db47b3f4a1267e10594576d52730ec1">Can I share my room preference while confirming my booking?
            </h2>
            <div id="collapse-a443e01b4db47b3f4a1267e10594576d52730ec1" class="accordion-collapse collapse border-0 "
              aria-labelledby="heading-a443e01b4db47b3f4a1267e10594576d52730ec1" data-bs-parent="#accordionFAQ">
              <div class="accordion-body py-0 content">Hostelraja has robust customer support services and while confirming/booking a room you can share your room preferences with our executives.</div>
            </div>
          </div>
          <div class="accordion-item p-1 mb-2">
            <h2 class="accordion-header accordion-button h5 border-0 "
              id="heading-4b82be4be873c8ad699fa97049523ac86b67a8bd" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapse-4b82be4be873c8ad699fa97049523ac86b67a8bd" aria-expanded="false"
              aria-controls="collapse-4b82be4be873c8ad699fa97049523ac86b67a8bd">How many details I can upload here for managing my Hostel management?
            </h2>
            <div id="collapse-4b82be4be873c8ad699fa97049523ac86b67a8bd" class="accordion-collapse collapse border-0 "
              aria-labelledby="heading-4b82be4be873c8ad699fa97049523ac86b67a8bd" data-bs-parent="#accordionFAQ">
              <div class="accordion-body py-0 content">Hostelraja is high on technology and uses modern technology like cloud-based services where you can get Infinite storage, backup & recovery with anytime accessibility.</div>
            </div>
          </div>
          <div class="accordion-item p-1 mb-2">
            <h2 class="accordion-header accordion-button h5 border-0 "
              id="heading-3e13e9676a9cd6a6f8bfbe6e1e9fc0881ef247b3" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapse-3e13e9676a9cd6a6f8bfbe6e1e9fc0881ef247b3" aria-expanded="false"
              aria-controls="collapse-3e13e9676a9cd6a6f8bfbe6e1e9fc0881ef247b3">Can I visit the room before renting it?
            </h2>
            <div id="collapse-3e13e9676a9cd6a6f8bfbe6e1e9fc0881ef247b3" class="accordion-collapse collapse border-0 "
              aria-labelledby="heading-3e13e9676a9cd6a6f8bfbe6e1e9fc0881ef247b3" data-bs-parent="#accordionFAQ">
              <div class="accordion-body py-0 content">You buy what you see and that’s why we, at Hostelraja, are happy to give you a tour of the properties whenever you schedule a visit.</div>
            </div>
          </div>
          <div class="accordion-item p-1 mb-2">
            <h2 class="accordion-header accordion-button h5 border-0 "
              id="heading-0c2f829793a1f0562fea97120357dd2d43319164" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapse-0c2f829793a1f0562fea97120357dd2d43319164" aria-expanded="false"
              aria-controls="collapse-0c2f829793a1f0562fea97120357dd2d43319164">What benefits do we get as Hostel/PG owners after registration at Hostelraja?
            </h2>
            <div id="collapse-0c2f829793a1f0562fea97120357dd2d43319164" class="accordion-collapse collapse border-0 "
              aria-labelledby="heading-0c2f829793a1f0562fea97120357dd2d43319164" data-bs-parent="#accordionFAQ">
              <div class="accordion-body py-0 content">Managing Hostel/PGs documentation is tough but with Hostelraja you will get the whole management system at your fingertips from tenant details to their payment everything with ease. You will also get features to send reminders to the tenants for the due rents, etc.</div>
            </div>
          </div>
          <div class="accordion-item p-1 mb-2">
            <h2 class="accordion-header accordion-button h5 border-0 "
              id="heading-8fe6730e26db16f15763887c30a614caa075f518" type="button" data-bs-toggle="collapse"
              data-bs-target="#collapse-8fe6730e26db16f15763887c30a614caa075f518" aria-expanded="false"
              aria-controls="collapse-8fe6730e26db16f15763887c30a614caa075f518">How can I book my accommodation with Hostelraja?
            </h2>
            <div id="collapse-8fe6730e26db16f15763887c30a614caa075f518" class="accordion-collapse collapse border-0 "
              aria-labelledby="heading-8fe6730e26db16f15763887c30a614caa075f518" data-bs-parent="#accordionFAQ">
              <div class="accordion-body py-0 content">When you’re at Hostelraja, your booking is just a click away. You can book your stay through the website. You can browse through the properties and the amenities online and we will schedule your visits before/after the booking is confirmed.</div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 mt-4 mt-lg-0">
        <div class="shadow rounded py-5 px-4 ms-0 ms-lg-4 bg-white position-relative">
          <div class="block mx-0 mx-lg-3 mt-0">
            <h4 class="h5">Still Have Questions?</h4>
            <div class="content">Call Us We Will Be Happy To Help
              <br> <a href="tel:+919649887888">+91 96498 87888</a>
              <br>Monday - Friday
              <br>10AM TO 07PM</div>
          </div>
          <div class="block mx-0 mx-lg-3 mt-4">
            <h4 class="h5">Address</h4>
            <div class="content">Office No. – 314, 3rd Floor,
                                    Balaji tower-6 Near Hotel Radisson blu,
                                    Durgapur Flyover,
                                    Tonk Road Jaipur,
                                    Rajasthan, India, Pin – 302018</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<?php include ("include/footer.php"); ?>
<?php include ("include/footerlink.php"); ?>

 <!-- Swiper JS -->
 <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- Initialize Swiper -->
<script>
  var swiper = new Swiper(".mySwiper", {
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },

    autoplay: {
          delay: 2500,
          disableOnInteraction: false,
        },
  });
</script>
</body>
</html>