
<!DOCTYPE html>
<html lang="en">
    <head>
        <style>
.btn-links{
    margin-bottom: 10px;
}
[type="button"]:not(:disabled), [type="reset"]:not(:disabled), [type="submit"]:not(:disabled), button:not(:disabled) {
  cursor: pointer;
  margin: 0 3px;
}
 </style>
<div id="layout-wrapper">
<?php include("include/headerlink.php"); ?>
<?php include("include/header.php"); ?>
    <?php include("include/menu.php"); ?>

    <div class="main-content">

<div class="page-content">
    <div class="container-fluid" style="max-width: 95%;">

        <!-- start page title -->
        <div class="row"style="margin-top: 44px;" >
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0 font-size-18">Collection Summary</h4>

                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                        <select class="form-control">
                                    <option>Hostelraja</option>
                                </select>
                        </ol>
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->
        <div class="row">  
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                       <div class="row"> 
                           <div class="col-lg-3">
                           <div class="mb-3">
                                <label class="form-label">From</label>
                                <input type="date" class="form-control" placeholder="">
                            </div>
                           </div>
                           <div class="col-lg-3">
                           <div class="mb-3">
                                <label class="form-label"> To</label>
                                <input type="date" class="form-control" placeholder="">
                            </div>
                           </div>
                           <div class="col-lg-3">
                           <label class="form-label">Total Count- 0</label>
                           </div>
                           <div class="col-lg-3">
                           <label class="form-label">Total Collection- ₹ 0.00</label>
                           </div>
                       </div>

                    <table id="datatable-buttons" class="table table-bordered dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Date</th>
                                <th>Count</th>
                                <th>Amount</th>
                                <th>Action</th>
                            </tr>
                            </thead>


                            <tbody>
                            <tr>
                                <td>1</td>
                                <td>System Architect</td>
                                <td>Edinburgh</td>
                                <td>61</td>
                                <td>2011/04/25</td>
                               
                                
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Accountant</td>
                                <td>Tokyo</td>
                                <td>63</td>
                                <td>2011/07/25</td>

                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Junior Technical Author</td>
                                <td>San Francisco</td>
                                <td>66</td>
                                <td>2009/01/12</td>
        
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>Senior Javascript Developer</td>
                                <td>Edinburgh</td>
                                <td>22</td>
                                <td>2012/03/29</td>
                               
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>Accountant</td>
                                <td>Tokyo</td>
                                <td>33</td>
                                <td>2008/11/28</td>
                                
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>Integration Specialist</td>
                                <td>New York</td>
                                <td>61</td>
                                <td>2012/12/02</td>

                            </tr>
                            <tr>
                                <td>7</td>
                                <td>Sales Assistant</td>
                                <td>San Francisco</td>
                                <td>59</td>
                                <td>2012/08/06</td>
                               
                            </tr>
                            <tr>
                                <td>8</td>
                                <td>Integration Specialist</td>
                                <td>Tokyo</td>
                                <td>55</td>
                                <td>2010/10/14</td>
                                
                            </tr>
                            <tr>
                                <td>9</td>
                                <td>Javascript Developer</td>
                                <td>San Francisco</td>
                                <td>39</td>
                                <td>2009/09/15</td>
                                
                            </tr>
                            <tr>
                                <td>10</td>
                                <td>Software Engineer</td>
                                <td>Edinburgh</td>
                                <td>23</td>
                                <td>2008/12/13</td>
                               
                            </tr>
                            <tr>
                                <td>11</td>
                                <td>Office Manager</td>
                                <td>London</td>
                                <td>30</td>
                                <td>2008/12/19</td>
                                
                            </tr>
                            <tr>
                                <td>12</td>
                                <td>Support Lead</td>
                                <td>Edinburgh</td>
                                <td>22</td>
                                <td>2013/03/03</td>
                               
                            </tr>
                            <tr>
                                <td>13</td>
                                <td>Regional Director</td>
                                <td>San Francisco</td>
                                <td>36</td>
                                <td>2008/10/16</td>
                                
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div> <!-- container-fluid -->
</div>
                    <!-- End Page-content -->
        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

       <?php include("include/footer.php");?>
       <?php include("include/footerlink.php");?>
    </body>
    </html>
    </body>