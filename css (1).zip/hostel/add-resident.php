
<!DOCTYPE html>
<html lang="en">
<head>
<style>
.btn-links{
margin-bottom: 10px;
}
.detailslist{
    margin-top: 20px;
    font-size: 12px;
    font-weight: 600;
}
</style>
</head>
<body data-topbar="dark" data-layout="horizontal">

<!-- Begin page -->
<div id="layout-wrapper">

<?php include("include/header.php"); ?>
<?php include("include/headerlink.php"); ?>
<?php include("include/menu.php"); ?>

<div class="main-content">

<div class="page-content">
<div class="container-fluid" style="max-width: 95%;">

<!-- start page title -->
<div class="row"style="margin-top: 44px;" >
<div class="col-12">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h2 class="mb-sm-0 font-size-70" style="color: ;">Add Resident</h2>

        <div class="page-title-right">
            <ol class="breadcrumb m-0">
            <a href="resident.php" class="btn btn-outline-secondary waves-effect" tabindex="-1" role="button" aria-disabled="true" style="width: 100px;">Next</a>
            </ol>
        </div>

    </div>
</div>
</div>
</div>
<!-- end page title -->
<div class="row">
<div class="col-lg-12">
<div class="card">
<div class="card-body">
    
<h2 class="card-title">Personal Details</h2>

<form>
<div class="row">
<div class="col-lg-3">
    <div class="mb-3">
<label class="form-label">Resident Name *</label>
        <input type="text" class="form-control" placeholder=""> 
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Contact*</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">DOB</label>
        <input type="date" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Martial Status</label>
        <select class="form-control select2">
                <option value="">None</option>
                <option value="">Single</option>
                <option value="">Married</option>
        </select>

    </div>
</div>
</div>

<div class="row">
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Gender</label>
        <select class="form-control select2">
                <option value="">Male</option>
                <option value="">Female</option>
        </select>

    </div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Address</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">District</label>
        <input type="text" class="form-control" placeholder=""> 
</div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">State</label>
        <select class="form-control select2">
                <option value="">Select State</option>
                <option value="">Ranchi</option>
        </select>

    </div>
</div>
</div>
<div class="row">
<div class="col-lg-3 ">
<div class="mb-3">
<label class="form-label">Courses</label>
        <input type="text" class="form-control" placeholder=""> 
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Organization/Institude</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Government Id Proof</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Agreement</label>
        <select class="form-control select2">
                <option value="">1 Months</option>
                <option value="">2 Months</option>
                <option value="">3 Months</option>
                <option value="">4 Months</option>
                <option value="">5 Months</option>
                <option value="">6 Months</option>
                <option value="">7 Months</option>
                <option value="">8 Months</option>
                <option value="">9 Months</option>
                <option value="">10 Months</option>
                <option value="">11 Months</option>
                <option value="">12 Months</option>
        </select>

    </div>
</div>
</div>
<div class="row">
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Registration Date *</label>
        <input type="date" class="form-control" placeholder=""> 
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Email</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
</div>
<div class="detailslist"><h2 class="card-title">Guardian Details</h2></div>

<div class="row">
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Father Name</label>
        <input type="text" class="form-control" placeholder=""> 
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Father's Contact</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Father's Occuption</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Mother Name</label>
        <input type="text" class="form-control" placeholder=""> 
</div>
</div>
</div>

<div class="row">
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Mother's Contact</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Mother's Occuption</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Local Guardian's Name</label>
        <input type="text" class="form-control" placeholder=""> 
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Local Guardian's Contact</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
</div>

<div class="row">
<div class="col-lg-3">
    <div class="mb-3">
<label class="form-label">Local Guardian's Address</label>
        <input type="text" class="form-control" placeholder="">
</div>
</div>
</div>

<div class="row">
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Image</label>
        <input type="file" class="form-control" placeholder=""> 
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Id Proof 1</label>
        <input type="file" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Id Proof 2</label>
        <input type="file" class="form-control" placeholder="">
</div>
</div>
<div class="col-lg-3">
<div class="mb-3">
<label class="form-label">Id Proof 3</label>
        <input type="file" class="form-control" placeholder=""> 
</div>
</div>
</div>
<div class="row">
<div class="col-lg-3">
    <div class="mb-3">
<label class="form-label">Resident Signature</label>
        <input type="file" class="form-control" placeholder=""> 
</div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
<label class="form-label">Parent Signature</label>
        <input type="file" class="form-control" placeholder="">
</div>
</div>
<div class="detailslist"><h2 class="card-title">Resident Accomodations</h2></div>
 <div class="row">
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Branch *</label>
        <select class="form-control ">
            <option>Select Branch</option>
                <option value="AK">Alaska</option>
                <option value="HI">Hawaii</option>
        </select>

    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Room *</label>
        <select class="form-control select2">
            <option>Select Room</option>
                <option value="AK">Alaska</option>
                <option value="HI">Hawaii</option>
        </select>

    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Bed *</label>
        <select class="form-control select2">
            <option>Select Branch</option>
                <option value="AK">Alaska</option>
                <option value="HI">Hawaii</option>
        </select>

    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Tarrif *</label>
        <input type="text" class="form-control" placeholder="">

    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Security Amount</label>
        <input type="text" class="form-control" placeholder="">
    </div>
</div>
<div class="row">
<div class="">
    <div class="mb-3">
    <input class="coupon_question" type="checkbox" name="coupon_question" value="1" onchange="valueChanged()"/> &nbsp;
    <label class="form-label">Pay Now</label>
</div>
<section class="clickup" style="display: none;">
 <div class="row">
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Next Due Date *</label>
        <input type="date" class="form-control" placeholder="">

    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Paymode</label>
        <input type="text" class="form-control" placeholder="">

    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Remark</label>
        <input type="text" class="form-control" placeholder="">

    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Rent Amount (A) *</label>
        <input type="text" class="form-control" placeholder="">

    </div>
</div>
</div>
<div class="row">
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Security Amount (B)</label>
        <input type="text" class="form-control" placeholder="">
    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Advance (C)</label>
        <input type="text" class="form-control" placeholder="">
    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Service Charges (D)</label>
        <input type="text" class="form-control" placeholder="">
    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Electricity Charges (E)</label>
        <input type="text" class="form-control" placeholder="">
    </div>
</div>
</div>
<div class="row">
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Gas Charges (F)</label>
        <input type="text" class="form-control" placeholder="">
    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Water Charges (G)</label>
        <input type="text" class="form-control" placeholder="">
    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Other Charges (H)</label>
        <input type="text" class="form-control" placeholder="">

    </div>
</div>
<div class="col-lg-3">
    <div class="mb-3">
        <label class="form-label">Discount (₹) (I)</label>
        <input type="text" class="form-control" placeholder="">

    </div>
</div>
</div>
<div class="row">
<div class="col-lg-6">
    <div class="mb-3">
        <label class="form-label">Total Amount (A+B+C+D+E+F+G+H-I)</label>
        <input type="text" class="form-control" placeholder="">
    </div>
</div>
</div>
</section>
<button type="button" class="btn btn-success waves-effect waves-light" style="margin-bottom: 10px; width:100px">Reset</button>
<button type="button" class="btn btn-primary waves-effect waves-light" style="margin-bottom: 10px; width:100px">Submit</button>
</form>
</div>
                        </div>
                    </div>
                    <!-- end select2 -->

                </div>


            </div>

</div> <!-- container-fluid -->
</div>
<!-- End Page-content -->
<!-- Right bar overlay-->
<div class="rightbar-overlay"></div>

<?php include("include/footer.php");?>
<?php include("include/footerlink.php");?>

<script type="text/javascript">
    function valueChanged()
    {
        if($('.coupon_question').is(":checked"))   
            $(".clickup").show();
        else
            $(".clickup").hide();
    }
</script>
</body>
</html>
</body>