
<!DOCTYPE html>
<html lang="en">
    <head>
        <style>
.btn-links{
    margin-bottom: 10px;
}
[type="button"]:not(:disabled), [type="reset"]:not(:disabled), [type="submit"]:not(:disabled), button:not(:disabled) {
  cursor: pointer;
  margin: 0 3px;
}
 </style>
<div id="layout-wrapper">
<?php include("include/headerlink.php"); ?>
<?php include("include/header.php"); ?>
    <?php include("include/menu.php"); ?>

    <div class="main-content">

<div class="page-content">
    <div class="container-fluid" style="max-width: 95%;">

        <!-- start page title -->
        <div class="row"style="margin-top: 44px;" >
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0 font-size-18">Room Occupancy</h4>

                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">                   
                    <select class="form-control">
                                    <option>Hostelraja</option>
                                </select>
                        </ol>
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->
        <div class="row">  
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                       <div class="row">
                           <div class="col-lg-3">
                           <div class="mb-3">
                                <label class="form-label">From</label>
                                <input type="date" class="form-control" placeholder="">
                            </div>
                           </div>
                           <div class="col-lg-3">
                           <div class="mb-3">
                                <label class="form-label"> To</label>
                                <input type="date" class="form-control" placeholder="">
                            </div>
                           </div>
                       </div>
                    <table id="datatable-buttons" class="table table-bordered dt-responsive nowrap w-100">
                            <thead>
                            <tr>
                                <th>Room No.</th>
                                <th>Resident No.</th>
                                <th>Floor No.</th>
                            </tr>
                            </thead>


                            <tbody>
                            <tr>
                                <td>Tiger Nixon</td>
                                <td>System Architect</td>
                                <td>Edinburgh</td>
                                
                            </tr>
                            <tr>
                                <td>Garrett Winters</td>
                                <td>Accountant</td>
                                <td>Tokyo</td>
                                

                            </tr>
                            <tr>
                                <td>Ashton Cox</td>
                                <td>Junior Technical Author</td>
                                <td>San Francisco</td>
                                
        
                            </tr>
                            <tr>
                                <td>Cedric Kelly</td>
                                <td>Senior Javascript Developer</td>
                                <td>Edinburgh</td>
                               
                               
                            </tr>
                            <tr>
                                <td>Airi Satou</td>
                                <td>Accountant</td>
                                <td>Tokyo</td>
                               
                                
                            </tr>
                            <tr>
                                <td>Brielle Williamson</td>
                                <td>Integration Specialist</td>
                                <td>New York</td>
                                

                            </tr>
                            <tr>
                                <td>Herrod Chandler</td>
                                <td>Sales Assistant</td>
                                <td>San Francisco</td>
                               
                               
                            </tr>
                            <tr>
                                <td>Rhona Davidson</td>
                                <td>Integration Specialist</td>
                                <td>Tokyo</td>
                              
                                
                            </tr>
                            <tr>
                                <td>Colleen Hurst</td>
                                <td>Javascript Developer</td>
                                <td>San Francisco</td>
                                
                                
                            </tr>
                            <tr>
                                <td>Sonya Frost</td>
                                <td>Software Engineer</td>
                                <td>Edinburgh</td>
                               
                               
                            </tr>
                            <tr>
                                <td>Jena Gaines</td>
                                <td>Office Manager</td>
                                <td>London</td>
                                
                                
                            </tr>
                            <tr>
                                <td>Quinn Flynn</td>
                                <td>Support Lead</td>
                                <td>Edinburgh</td>
                                
                               
                               
                            </tr>
                            <tr>
                                <td>Charde Marshall</td>
                                <td>Regional Director</td>
                                <td>San Francisco</td>
                               
                                
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div> <!-- container-fluid -->
</div>
                    <!-- End Page-content -->
        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

       <?php include("include/footer.php");?>
       <?php include("include/footerlink.php");?>
    </body>
    </html>
    </body>