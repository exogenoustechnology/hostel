
<footer class="footer" style="background-color: #18325c !important;">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-sm-6" style="color:#fff;">
                                <script>document.write(new Date().getFullYear())</script> © HostelRaja.
                            </div>
                            <!-- <div class="col-sm-6">
                                <div class="text-sm-end d-none d-sm-block">
                                    Design & Develop by Themesbrand
                                </div> -->
                            </div>
                        </div>
                    </div>
                </footer>