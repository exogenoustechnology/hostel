<!DOCTYPE html>
<html lang="en">
    <head>
        <style>
  #topnav-menu-content {
  width: 100%;
  overflow: scroll;
    overflow-y: scroll;
  overflow-y: hidden;
  display: flex;
} 

    .dropdown, .dropend, .dropstart, .dropup {
    position: initial;
    z-index: 999;
}

        </style>
        </head>
        <body>
        <div class="topnav">
        <div class="container-fluid">
            <nav class="navbar navbar-light navbar-expand-lg topnav-menu">

                <div class="collapse navbar-collapse" id="topnav-menu-content">
                    <ul class="navbar-nav">

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-dashboard" role="button"
                            >
                                <i class="bx bx-home-circle me-2"></i><span key="t-dashboards">Dashboards</span> <div class="arrow-down"></div>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="topnav-dashboard">

                                <a href="home.php" class="dropdown-item" key="t-default">Home</a>
                            </div>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-uielement" role="button"
                            >
                                <i class="bx bx-tone me-2"></i>
                                <span key="t-ui-elements"> Master</span> 
                                <div class="arrow-down"></div>
                            </a>

                            <div class="dropdown-menu mega-dropdown-menu px-2 dropdown-mega-menu-xl"
                                aria-labelledby="topnav-uielement">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div>
                                            <a href="branches-list.php" class="dropdown-item" key="t-alerts">Branches</a>
                                            <a href="room-list.php" class="dropdown-item" key="t-buttons">Room</a>
                                            <a href="Bed.php" class="dropdown-item" key="t-cards">Bed</a>
                                            <a href="Manager.php" class="dropdown-item" key="t-carousel">Manager</a>
                                            <a href="term-condition.php" class="dropdown-item" key="t-dropdowns">Term & Conditions</a>
                                            <a href="branch-amenities.php" class="dropdown-item" key="t-images">Branch Amentity</a>
                                            <!-- <a href="ui-lightbox.html" class="dropdown-item" key="t-lightbox"> Add Staff Details </a> -->
                                            <a href="complaint.php" class="dropdown-item" key="t-images">Complaint</a>
                                            <a href="slider.php" class="dropdown-item" key="t-lightbox">Slider </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link dropdown-toggle arrow-none" href="resident.php" id="topnav-pages" role="button" >
                                <i class="bx bx-customize me-2"></i><span key="t-apps">Resident</span><div class="arrow-down"></div>
                            </a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="payments.php" id="topnav-components" role="button"
                            >
                                <i class="bx bx-collection me-2"></i><span key="t-components">Payments</span> <div class="arrow-down"></div>
                            </a>

                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-more" role="button">
                                <i class="bx bx-file me-2"></i><span key="t-extra-pages">Reports</span> <div class="arrow-down"></div>
                            </a>
                           
                            <div class="dropdown-menu mega-dropdown-menu px-2 dropdown-mega-menu-xl"
                                aria-labelledby="topnav-uielement">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div>
                    <a href="residents-report.php" class="dropdown-item" key="t-alerts"> Residents Report</a>
                    <a href="room-revenue.php" class="dropdown-item" key="t-buttons"> Room Revenue</a>
                    <a href="room-occupancy.php" class="dropdown-item" key="t-cards"> Room Occupancy</a>
                    <a href="collection-summary.php" class="dropdown-item" key="t-carousel">Collection Summary</a>
                    <a href="refunds.php" class="dropdown-item" key="t-dropdowns">Refunds</a>
                    <a href="security-summary.php" class="dropdown-item" key="t-grid">Security  Summary</a>
                    <a href="salaries-report.php" class="dropdown-item" key="t-images"> Day-wise Report</a>
                    <a href="salaries-report.php" class="dropdown-item" key="t-lightbox"> Salaries Report </a>
                    <a href=" agreement-report.php" class="dropdown-item" key="t-lightbox"> Agreement Report </a>
                    <a href=" notice-period.php " class="dropdown-item" key="t-lightbox"> Notice Period Report </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-layout" role="button"
                            >
                                <i class="bx bx-layout me-2"></i><span key="t-layouts">Enquiry</span> <div class="arrow-down"></div>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="topnav-layout">
                                <div class="dropdown">
                                    <a class="dropdown-item dropdown-toggle arrow-none" href="#" id="topnav-layout-verti"
                                        role="button">
                                        <span key="t-vertical">Vertical</span> <div class="arrow-down"></div>
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="topnav-layout-verti">
                                        <a href="layouts-light-sidebar.html" class="dropdown-item" key="t-light-sidebar">Light Sidebar</a>
                                        <a href="layouts-compact-sidebar.html" class="dropdown-item" key="t-compact-sidebar">Compact Sidebar</a>
                                        <a href="layouts-icon-sidebar.html" class="dropdown-item" key="t-icon-sidebar">Icon Sidebar</a>
                                        <a href="layouts-boxed.html" class="dropdown-item" key="t-boxed-width">Boxed Width</a>
                                        <a href="layouts-preloader.html" class="dropdown-item" key="t-preloader">Preloader</a>
                                        <a href="layouts-colored-sidebar.html" class="dropdown-item" key="t-colored-sidebar">Colored Sidebar</a>
                                        <a href="layouts-scrollable.html" class="dropdown-item" key="t-scrollable">Scrollable</a>
                                    </div>
                                </div>

                                <div class="dropdown">
                                    <a class="dropdown-item dropdown-toggle arrow-none" href="#" id="topnav-layout-hori"
                                        role="button">
                                        <span key="t-horizontal">Horizontal</span> <div class="arrow-down"></div>
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="topnav-layout-hori">
                                        <a href="layouts-horizontal.html" class="dropdown-item" key="t-horizontal">Horizontal</a>
                                        <a href="layouts-hori-topbar-light.html" class="dropdown-item" key="t-topbar-light">Topbar light</a>
                                        <a href="layouts-hori-boxed-width.html" class="dropdown-item" key="t-boxed-width">Boxed width</a>
                                        <a href="layouts-hori-preloader.html" class="dropdown-item" key="t-preloader">Preloader</a>
                                        <a href="layouts-hori-colored-header.html" class="dropdown-item" key="t-colored-topbar">Colored Header</a>
                                        <a href="layouts-hori-scrollable.html" class="dropdown-item" key="t-scrollable">Scrollable</a>
                                    </div>
                                </div>
                            </div>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-layout" role="button" >
                                <i class="bx bx-layout me-2"></i><span key="t-layouts">Staff</span> <div class="arrow-down"></div>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-dashboard" role="button"
                            >
                                <i class="bx bx-home-circle me-2"></i><span key="t-dashboards">Cash Management</span> <div class="arrow-down"></div>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="topnav-dashboard">

                                <a href="#" class="dropdown-item" key="t-default">Default</a>
                                <a href="#" class="dropdown-item" key="t-saas">Saas</a>
                                <a href="#" class="dropdown-item" key="t-crypto">Crypto</a>
                                <a href="#" class="dropdown-item" key="t-blog">Blog</a>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-uielement" role="button"
                            >
                                <i class="bx bx-tone me-2"></i>
                                <span key="t-ui-elements">About Us & Support</span> 
                                <div class="arrow-down"></div>
                            </a>

                            <div class="dropdown-menu mega-dropdown-menu px-2 dropdown-mega-menu-xl"
                                aria-labelledby="topnav-uielement">
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div>
                                            <a href="ui-alerts.html" class="dropdown-item" key="t-alerts">Branches</a>
                                            <a href="ui-buttons.html" class="dropdown-item" key="t-buttons">Room</a>
                                            <a href="ui-cards.html" class="dropdown-item" key="t-cards">Bed</a>
                                            <a href="ui-carousel.html" class="dropdown-item" key="t-carousel">Manager</a>
                                            <a href="ui-dropdowns.html" class="dropdown-item" key="t-dropdowns">Term & Conditions</a>
                                            <a href="ui-grid.html" class="dropdown-item" key="t-grid">Branches</a>
                                            <a href="ui-images.html" class="dropdown-item" key="t-images">Branch Amentity</a>
                                            <a href="ui-lightbox.html" class="dropdown-item" key="t-lightbox"> Add Staff Details </a>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-pages" role="button">
                                <i class="bx bx-customize me-2"></i><span key="t-apps">Additonal Functionality</span><div class="arrow-down"></div>
                            </a>
                        </li>

                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-components" role="button">
                                <i class="bx bx-collection me-2"></i><span key="t-components">My Details</span> <div class="arrow-down"></div>
                            </a>
                            
                        </li>

                    </ul>
                </div>
            </nav>
        </div>
    </div>
        </body>
        </html>