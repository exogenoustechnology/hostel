
<!DOCTYPE html>
<html lang="en">
    <head>
        <style>
.btn-links{
    margin-bottom: 10px;
}
 </style>
<div id="layout-wrapper">
<?php include("include/headerlink.php"); ?>
<?php include("include/header.php"); ?>
    <?php include("include/menu.php"); ?>

    <div class="main-content">

<div class="page-content">
    <div class="container-fluid" style="max-width: 95%;">

        <!-- start page title -->
        <div class="row"style="margin-top: 44px;" >
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0 font-size-18">Branch Amenities</h4>
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal1">Add Branch Amenities</button>
                        </ol>
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->
        <div class="row">  
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3" style="float: left;">
                               <select class="form-control">
                                <option>Xero Max</option>
                             </select>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3" style="float: right;">
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal"> Update Amenity</button>
                            </div>
                        </div>
                      </div>
                        </div>
                   </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div> <!-- container-fluid -->
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"> Update Amenity</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Head Name*</label>
                                <input type="text" class="form-control" placeholder="">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Description*</label>
                                <input type="text" class="form-control" placeholder="">
                            </div>
                        </div>
                      </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Save changes</button>
                        </div>
                        </div>
                    </div>
                    </div>

<!-- Modal -->
<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel"> Update Amenity</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                        <div class="row">
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Head Name*</label>
                                <input type="text" class="form-control" placeholder="">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label">Description*</label>
                                <input type="text" class="form-control" placeholder="">
                            </div>
                        </div>
                      </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Save changes</button>
                        </div>
                        </div>
                    </div>
                    </div>
<!-- End Page-content -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

       <?php include("include/footer.php");?>
       <?php include("include/footerlink.php");?>
    </body>
    </html>
    </body>