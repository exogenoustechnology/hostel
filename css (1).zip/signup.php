<?php include ("include/headerlink.php"); ?>
<!DOCTYPE html>
<html lang="en">
 <head>
    <title>New Registration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
.pg-regpage {
    width: 70%;
    position: relative;
    background: #ffffffde;
    flex: 1 1 auto;
    border: 2px;
    margin-top: 80px;
    margin-bottom: 80px;
    margin-left: auto;
    margin-right: auto;
    border-color: black;
    shape-outside: border-box;
    padding: 20px 20px 20px 20px;
    align-items: center;
    box-shadow: 5px 10px rgb(255 100 60);
}
body  {
  background-image: url("images/boys-students-ordering.webp");
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center;
  background-size: cover;
}

.form_img {
    vertical-align: middle;
    border: 0;
    display: flex;
    max-width: 100px;
    height: auto;
    margin-left: auto;
    margin-right: auto;
    padding-bottom: 30px;
}
  </style>
</head>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script> 
<script src="//geodata.solutions/includes/statecity.js"></script>

<body>

<div class="pg-regpage">
<img class="form_img" src="images/hostelraja.png">
      <form action="#!" method="post">
          <div class="row">
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_full_name" class="form-label">Pg Name*</label>
                <input type="text" class="form-control shadow-none" id="loan_full_name">
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_password" class="form-label">contact 1*</label>
                <input type="password" class="form-control shadow-none" id="loan_password">
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_full_name" class="form-label">contact 2*</label>
                <input type="text" class="form-control shadow-none" id="loan_full_name">
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_password" class="form-label">Branch Type*</label>
                <select class="form-control" name="type" required="">
                  <option value="1">Boys</option>
                  <option value="2">Girls</option>
                  <option value="3">Co-Ed</option>
                </select>
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_full_name" class="form-label">Owner Name*</label>
                <input type="text" class="form-control shadow-none" id="loan_full_name">
              </div>
            </div>
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_owner" class="form-label">Owner Mail*</label>
                <input type="text" class="form-control shadow-none" id="loan_password">
              </div>
            </div>
            <div class="col-lg-12 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_address" class="form-label">Address*</label>
                <input type="text" class="form-control shadow-none" id="loan_address">
              </div>
            </div>
            <div class="col-lg-12 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_full_name" class="form-label">PAN Number*</label>
                <input type="text" class="form-control shadow-none" id="loan_full_name">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_password" class="form-label">State*</label>
                <select name="state" class="states order-alpha form-control " id="stateId">
                  <option value="">Select State</option>
              </select>
                            </div>
            </div>
         
            <div class="col-lg-6 mb-4 pb-2">
              <div class="form-group">
                <label for="loan_password" class="form-label">City*</label>
                <input type="hidden" name="country" id="countryId" value="IN"/>
                <select name="city" class="cities order-alpha form-control" id="cityId">
                    <option value="">Select City</option>
                </select>
              </div>
            </div></div>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Save</button>
        <button type="button" class="btn btn-primary">cancel</button>          
        </form>
      </div>
    </div>
  </div>
  <?php include ("include/footerlink.php"); ?>
</body>
</html>
